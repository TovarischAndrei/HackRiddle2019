# HackRiddle2019
This is my repository for my work during Hack Riddle 2019!
Here i'll be trying to learn how to use HTML, CSS, and Bootstrap to make iterations of my own personal website.

